import os, zipfile
root = "."
out = "fusion-lens-threads-v1.0.0.zip"
skip_dirs = {".git", ".workbuddy", "__pycache__", "node_modules"}
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for dp, _, fns in os.walk(root):
        if any(p in skip_dirs for p in dp.split(os.sep)):
            continue
        for fn in fns:
            fp = os.path.join(dp, fn)
            if fp == out:
                continue
            if fn.endswith(".log"):
                continue
            arc = os.path.relpath(fp, root).replace("\\", "/")
            z.write(fp, arc)
imgs = [x for x in zipfile.ZipFile(out).namelist() if "docs/images/" in x and not x.endswith("README.md")]
print("Images in zip:", len(imgs))
for x in sorted(imgs):
    print(" ", x)
print("Total:", os.path.getsize(out), "bytes")
